module.exports = {
  APIURL: "http://your-api-url",
  JWTSecret: "your-jwt-secret",
  AdminRoute: "/admin/login",
  EmployeeRoute: "/employee/login",
};
