module.exports = {
  HOST: "arihikodb.cimar7cfkxbz.ap-southeast-1.rds.amazonaws.com",
  USER: "admin",
  PASSWORD: "ArihikoDB",
  DB: "employee_info",
};
